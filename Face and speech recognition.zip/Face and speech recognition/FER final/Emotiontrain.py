#load libraries
from keras.applications import MobileNet
from keras.models import Sequential,Model 
from keras.layers import Dense,Dropout,Activation,Flatten,GlobalAveragePooling2D
from keras.layers import Conv2D,MaxPooling2D,ZeroPadding2D
from keras.layers.normalization import BatchNormalization
from keras.preprocessing.image import ImageDataGenerator
from keras.optimizers import RMSprop,Adam
from keras.callbacks import ModelCheckpoint,EarlyStopping,ReduceLROnPlateau

#Define variable and values
img_rows,img_cols = 224,224
T_classes = 5
train_samples = 24176
validation_samples = 3006
epochs = 1
batch_size = 32

# Define MobileNet application
MobileNet = MobileNet(weights='imagenet',include_top=False,input_shape=(img_rows,img_cols,3))

# Layers are set to trainable as True 
for layer in MobileNet.layers:
    layer.trainable = True

def addTopModelMobileNet(bottom_model, T_classes):
    """creates the top or head of the model that will be 
    placed ontop of the bottom layers"""
    top_m = bottom_model.output
    top_m = GlobalAveragePooling2D()(top_m)
    top_m = Dense(1024,activation='relu')(top_m)
    top_m = Dense(1024,activation='relu')(top_m)
    top_m = Dense(512,activation='relu')(top_m)
    top_m = Dense(T_classes,activation='softmax')(top_m)
    return top_m

top_m = addTopModelMobileNet(MobileNet, T_classes)
model = Model(inputs = MobileNet.input, outputs = top_m)

train_dir = 'C:/Ai Assignment/AI Final Face/Face/TRAINDATA/train'
validation_dir = 'C:/Ai Assignment/AI Final Face/Face/TRAINDATA/validation'

train_dataimg = ImageDataGenerator(rescale=1./255,rotation_range=30,width_shift_range=0.3,
                                    height_shift_range=0.3,horizontal_flip=True,fill_mode='nearest' )

validation_dataimg = ImageDataGenerator(rescale=1./255)
     
train_generator = train_dataimg.flow_from_directory(train_dir,target_size = (img_rows,img_cols),
                                                    batch_size = batch_size,class_mode = 'categorical')

validation_generator = validation_dataimg.flow_from_directory(validation_dir,target_size=(img_rows,img_cols),
                                                                batch_size=batch_size,class_mode='categorical')

checkpoint = ModelCheckpoint('emotionFace.h5',monitor='val_loss',mode='min',save_best_only=True,verbose=1)

earlystop = EarlyStopping(monitor='val_loss',min_delta=0,patience=10,verbose=1,restore_best_weights=True)

learning_rate_reduction = ReduceLROnPlateau(monitor='val_acc', patience=5, verbose=1, factor=0.2, min_lr=0.0001)

callbacks = [earlystop,checkpoint,learning_rate_reduction]

model.compile(loss='categorical_crossentropy',optimizer=Adam(lr=0.001),metrics=['accuracy'])

history = model.fit(train_generator,steps_per_epoch=train_samples//batch_size,epochs=epochs,
            callbacks=callbacks,validation_data=validation_generator,validation_steps=validation_samples//batch_size)

